# Focus Library Lock 1.0.0

選んだ集中モードがオンの間だけ、ホーム画面を一番奥まで横にスワイプしても
Appライブラリ（アプリ一覧）を出さない tweak です。

## 対象
- iPhone 7 / iOS 15.x / Dopamine（rootless）/ ElleKit
- SpringBoard のみに注入します

## 使い方
1. Sileo で DEB をインストール → リスプリング
2. 設定アプリ →「Focus Library Lock」
3. 「集中モード」で、止めたい集中モードを選ぶ
   （自分で作った集中モードは「カスタム名」に名前を書く）
4. その集中モードをオンにすると Appライブラリが出なくなり、
   オフにすると元どおり出ます

## 安全の作り
- すべてのフック・判定を @try/@catch で囲み、例外が出ても
  SpringBoard を落とさない作りにしています
- 集中モードの判定は 1 秒ごとの確認で、重い処理はフックの中で行いません
- データは消しません。アンインストール＋リスプリングで完全に戻ります

## ログ
`/var/mobile/Library/Logs/FocusLibraryLock.log`
（無ければ `/var/tmp/FocusLibraryLock.log`）
起動時に METHOD_DUMP（この iOS に実在するメソッド一覧）、
SWIZZLE_INSTALLED（有効になった止め方）、FOCUS_STATE（集中の判定）、
BLOCKED_PAGE_SET（実際に止めた記録）が残ります。
