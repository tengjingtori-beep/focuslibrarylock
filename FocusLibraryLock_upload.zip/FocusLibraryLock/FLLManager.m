// FocusLibraryLock — core logic
//
// What it does
//   While the Focus mode chosen in Settings is ON, the App Library page
//   (the page after the last Home Screen page) must not open. When that
//   Focus mode is OFF, everything behaves exactly like stock iOS.
//
// How it decides ( polled once per second, never trusting one source )
//   1. INFocusStatusCenter (Intents.framework, loaded at runtime):
//      focusStatus.isFocused  -> "some Focus mode is on".
//   2. Every other readable hint about *which* mode is on is collected
//      into one lowercase "raw" string: the focus status description,
//      the com.apple.donotdisturb defaults, and the on-disk
//      ModeConfigurations.json (names / identifiers of defined modes).
//   3. Matching:
//        - target "any"                -> block while isFocused
//        - a custom name is written    -> block while isFocused and the
//                                         raw string contains that name
//        - a preset target is chosen   -> block while isFocused and the
//                                         raw string contains one of its
//                                         keywords; if no raw mode info
//                                         could be read at all and the
//                                         "fallback" setting is ON,
//                                         block while isFocused.
//
// How it blocks ( layered, every layer guarded with @try/@catch )
//   A. Zero-argument BOOL getters that report whether the App Library /
//      trailing custom page exists are swizzled to answer NO while
//      blocking (isAppLibraryAllowed, hasTrailingCustomViewController…).
//   B. The trailingCustomViewController getter is swizzled to nil while
//      blocking.
//   C. Page-change setters on the folder controllers are swizzled: a
//      request to move to the App Library page index is dropped while
//      blocking (only when the regular page count could be determined).
//   D. If the user is already sitting in the App Library when blocking
//      turns on, the manager navigates back to the last Home Screen page.
//   Every candidate class/method is checked at runtime first; anything
//   that does not exist on this iOS is skipped and written to the log
//   (METHOD_DUMP lines), so a miss is diagnosable from the log file
//   instead of crashing SpringBoard. Nothing here runs synchronously
//   inside a system hook except the tiny swizzled getters/setters,
//   which only read one cached BOOL / integer compare.

#import "FLLManager.h"
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"

NSString * const kFLLPrefsID = @"com.tori.focuslibrarylock";
NSString * const kFLLPrefsChanged = @"com.tori.focuslibrarylock.changed";

// ---------- prefs ----------
static BOOL prefEnabled = YES;
static NSString *prefTargetMode = @"dnd";
static NSString *prefCustomName = @"";
static BOOL prefFallbackAny = YES;

static id FLLAppValue(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kFLLPrefsID);
}

void FLLLoadPrefs(void) {
    @try {
        id v;
        v = FLLAppValue(@"Enabled");        if (v) prefEnabled = [v boolValue];
        v = FLLAppValue(@"TargetMode");     if (v && [v isKindOfClass:NSString.class]) prefTargetMode = v;
        v = FLLAppValue(@"CustomModeName"); if (v && [v isKindOfClass:NSString.class]) prefCustomName = v;
        v = FLLAppValue(@"FallbackAnyFocus"); if (v) prefFallbackAny = [v boolValue];
        CFPreferencesAppSynchronize((__bridge CFStringRef)kFLLPrefsID);
    } @catch (__unused id e) {}
}

// ---------- log ----------
static NSFileHandle *fllLogHandle = nil;
static dispatch_queue_t fllLogQueue = nil;

static NSString *FLLLogPath(void) {
    NSString *p = @"/var/mobile/Library/Logs/FocusLibraryLock.log";
    if ([NSFileManager.defaultManager fileExistsAtPath:p]) return p;
    NSString *dir = @"/var/mobile/Library/Logs";
    if ([NSFileManager.defaultManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil] &&
        [NSFileManager.defaultManager createFileAtPath:p contents:nil attributes:nil]) return p;
    return @"/var/tmp/FocusLibraryLock.log";
}

void FLLLog(NSString *format, ...) {
    @try {
        va_list ap; va_start(ap, format);
        NSString *msg = [[NSString alloc] initWithFormat:format arguments:ap];
        va_end(ap);
        if (!fllLogQueue) fllLogQueue = dispatch_queue_create("com.tori.focuslibrarylock.log", DISPATCH_QUEUE_SERIAL);
        dispatch_async(fllLogQueue, ^{
            @try {
                if (!fllLogHandle) {
                    NSString *path = FLLLogPath();
                    [NSFileManager.defaultManager createFileAtPath:path contents:nil attributes:nil];
                    fllLogHandle = [NSFileHandle fileHandleForWritingAtPath:path];
                    [fllLogHandle seekToEndOfFile];
                }
                NSString *line = [NSString stringWithFormat:@"[%@] %@\n",
                    [NSDateFormatter localizedStringFromDate:[NSDate date] dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle], msg];
                [fllLogHandle writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
                [fllLogHandle synchronizeFile];
            } @catch (__unused id e) {}
        });
    } @catch (__unused id e) {}
}

// ---------- shared state ----------
static BOOL gBlocking = NO;
static BOOL gIsFocused = NO;
static NSString *gRawMode = @"";
static BOOL gRawModeKnown = NO;
static NSInteger gExceptionCount = 0;

static void FLLNoteException(NSString *where, id e) {
    gExceptionCount++;
    FLLLog(@"EXCEPTION %@: %@", where, e);
}

// ---------- focus probing ----------
@interface FLLManager ()
@property (nonatomic, strong) NSTimer *pollTimer;
@property (nonatomic) BOOL setupDone;
@property (nonatomic) BOOL swizzlesDone;
@property (nonatomic, strong) NSString *lastLoggedState;
@property (nonatomic, strong) NSMutableDictionary<NSString *, IMP> *origIMPs;
- (void)poll;
- (BOOL)computeBlockingWithFocused:(BOOL)focused raw:(NSString *)raw rawKnown:(BOOL)rawKnown;
- (void)installSwizzles;
- (void)dumpCandidateMethods;
- (void)bounceBackIfNeeded;
@end

// Keywords per preset target (lowercase, English identifier fragments + Japanese names)
static NSArray<NSString *> *FLLKeywordsForTarget(NSString *target) {
    if ([target isEqualToString:@"dnd"])        return @[@"donotdisturb", @"do-not-disturb", @"dnd", @"おやすみ", @"サイレント"];
    if ([target isEqualToString:@"personal"])   return @[@"personal", @"パーソナル", @"個人"];
    if ([target isEqualToString:@"work"])       return @[@"work", @"仕事", @"ワーク", @"勤務"];
    if ([target isEqualToString:@"sleep"])      return @[@"sleep", @"睡眠", @"就寝", @"おやすみ"];
    if ([target isEqualToString:@"driving"])    return @[@"driving", @"運転", @"車", @"ドライブ"];
    if ([target isEqualToString:@"fitness"])    return @[@"fitness", @"フィットネス", @"運動", @"ワークアウト"];
    if ([target isEqualToString:@"gaming"])     return @[@"gaming", @"ゲーム"];
    if ([target isEqualToString:@"mindfulness"]) return @[@"mindfulness", @"マインドフルネス", @"瞑想"];
    if ([target isEqualToString:@"reading"])    return @[@"reading", @"読書"];
    return @[];
}

@implementation FLLManager

+ (instancetype)shared {
    static FLLManager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[FLLManager alloc] init]; });
    return s;
}

+ (BOOL)shouldBlock { return gBlocking; }
+ (void)logLine:(NSString *)line { FLLLog(@"%@", line); }

- (void)reloadPrefs {
    FLLLoadPrefs();
    FLLLog(@"PREFS enabled=%d target=%@ custom=%@ fallbackAny=%d",
           prefEnabled, prefTargetMode, prefCustomName, prefFallbackAny);
    [self poll];
}

// ----- focus state: collect every readable hint -----
- (void)collectFocusStateFocused:(BOOL *)outFocused raw:(NSString **)outRaw rawKnown:(BOOL *)outKnown {
    BOOL focused = NO;
    NSMutableString *raw = [NSMutableString string];
    BOOL known = NO;
    @try {
        // (1) INFocusStatusCenter via Intents.framework (runtime load only)
        static Class centerClass = Nil;
        if (!centerClass) {
            void *h = dlopen("/System/Library/Frameworks/Intents.framework/Intents", RTLD_LAZY);
            if (h) centerClass = NSClassFromString(@"INFocusStatusCenter");
            if (!centerClass) FLLLog(@"FOCUS_PROBE Intents/INFocusStatusCenter not available");
        }
        if (centerClass) {
            id center = [centerClass performSelector:@selector(defaultCenter)];
            id status = [center performSelector:@selector(focusStatus)];
            if (status) {
                focused = [[status valueForKey:@"isFocused"] boolValue];
                [raw appendFormat:@" status=%@", [status description]];
                known = YES; // at least isFocused is trustworthy
            }
        }
    } @catch (id e) { FLLNoteException(@"collectFocusStatusCenter", e); }

    @try {
        // (2) Do Not Disturb defaults: any string values may name the active mode
        NSDictionary *dnd = [[NSUserDefaults standardUserDefaults] persistentDomainForName:@"com.apple.donotdisturb"];
        if (dnd.count) {
            [raw appendFormat:@" dnddefaults=%@", dnd];
        }
    } @catch (id e) { FLLNoteException(@"collectDNDDefaults", e); }

    @try {
        // (3) Mode configuration file: it lists ALL modes the user has
        // defined, not the active one, so it must never feed the match
        // (it would false-positive on every defined mode). Log it once
        // for diagnostics only.
        static BOOL dumpedConfig = NO;
        if (!dumpedConfig) {
            dumpedConfig = YES;
            NSString *path = @"/var/mobile/Library/DoNotDisturb/DB/ModeConfigurations.json";
            NSData *data = [NSData dataWithContentsOfFile:path];
            if (data) {
                NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                FLLLog(@"MODE_CONFIG_DUMP len=%lu head=%@", (unsigned long)data.length,
                       text.length > 800 ? [text substringToIndex:800] : (text ?: @"(binary)"));
            } else {
                FLLLog(@"MODE_CONFIG_DUMP file not readable at %@", path);
            }
        }
    } @catch (id e) { FLLNoteException(@"collectModeConfig", e); }

    @try {
        // (4) SpringBoard-side DND state objects, if present: read a few
        // well-known keys defensively and keep only their descriptions.
        for (NSString *clsName in @[@"DNDStateService", @"SBDNDStateService", @"DNDState"]) {
            Class cls = NSClassFromString(clsName);
            if (!cls) continue;
            [raw appendFormat:@" class:%@=present", clsName];
            id obj = nil;
            if ([cls respondsToSelector:@selector(sharedService)]) obj = [cls performSelector:@selector(sharedService)];
            else if ([cls respondsToSelector:@selector(sharedInstance)]) obj = [cls performSelector:@selector(sharedInstance)];
            if (obj) {
                for (NSString *key in @[@"currentState", @"state", @"activeMode", @"mode"]) {
                    @try {
                        id val = [obj valueForKey:key];
                        if (val) { [raw appendFormat:@" %@.%@=%@", clsName, key, val]; known = YES; }
                    } @catch (__unused id e) {}
                }
            }
        }
    } @catch (id e) { FLLNoteException(@"collectDNDStateObjects", e); }

    *outFocused = focused;
    *outRaw = [raw lowercaseString];
    *outKnown = known;
}

static BOOL FLLRawMentionsAnyPreset(NSString *raw) {
    if (!raw.length) return NO;
    for (NSString *t in @[@"dnd", @"personal", @"work", @"sleep", @"driving", @"fitness", @"gaming", @"mindfulness", @"reading"]) {
        for (NSString *kw in FLLKeywordsForTarget(t)) {
            if ([raw containsString:kw]) return YES;
        }
    }
    return NO;
}

- (BOOL)computeBlockingWithFocused:(BOOL)focused raw:(NSString *)raw rawKnown:(BOOL)rawKnown {
    (void)rawKnown;
    if (!prefEnabled) return NO;
    if (!focused) return NO;
    NSString *custom = [prefCustomName stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (custom.length) {
        if (raw.length && [raw containsString:[custom lowercaseString]]) return YES;
        // The custom name was not found in the hints. If the hints name a
        // known preset, a different mode is active -> do not block. If the
        // hints name nothing at all, the identity is unknown and the
        // fallback setting decides.
        if (FLLRawMentionsAnyPreset(raw)) return NO;
        return prefFallbackAny;
    }
    if ([prefTargetMode isEqualToString:@"any"]) return YES;
    for (NSString *kw in FLLKeywordsForTarget(prefTargetMode)) {
        if (raw.length && [raw containsString:kw]) return YES;
    }
    // No keyword matched. If the hints name a known preset, a different
    // mode is active. If they name nothing, identity is unknown and the
    // fallback setting decides.
    if (FLLRawMentionsAnyPreset(raw)) return NO;
    return prefFallbackAny;
}

- (void)poll {
    @try {
        BOOL focused = NO; NSString *raw = @""; BOOL known = NO;
        [self collectFocusStateFocused:&focused raw:&raw rawKnown:&known];
        BOOL was = gBlocking;
        gIsFocused = focused; gRawMode = raw; gRawModeKnown = known;
        gBlocking = [self computeBlockingWithFocused:focused raw:raw rawKnown:known];
        NSString *state = [NSString stringWithFormat:@"focused=%d blocking=%d target=%@ rawLen=%lu",
                           focused, gBlocking, prefTargetMode, (unsigned long)raw.length];
        if (![state isEqualToString:self.lastLoggedState] || was != gBlocking) {
            self.lastLoggedState = state;
            FLLLog(@"FOCUS_STATE %@ raw=%@", state, raw.length > 600 ? [raw substringToIndex:600] : raw);
            if (was != gBlocking) FLLLog(@"BLOCKING_CHANGED %d -> %d", was, gBlocking);
        }
        if (gBlocking) [self bounceBackIfNeeded];
    } @catch (id e) { FLLNoteException(@"poll", e); }
}

// ----- helpers to read folder-controller geometry defensively -----
static long long FLLCallLongLong(id obj, SEL sel) {
    if (!obj || ![obj respondsToSelector:sel]) return -1;
    @try {
        NSMethodSignature *sig = [obj methodSignatureForSelector:sel];
        if (!sig || sig.numberOfArguments != 2) return -1;
        NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
        inv.target = obj; inv.selector = sel;
        [inv invoke];
        long long v = -1; [inv getReturnValue:&v];
        return v;
    } @catch (__unused id e) { return -1; }
}

static id FLLCallObject(id obj, SEL sel) {
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    @try { return [obj performSelector:sel]; } @catch (__unused id e) { return nil; }
}

// Number of regular Home Screen pages (icon lists), or -1 if unknown.
// The App Library page index == this count (0-based pages 0..count-1 are
// icon lists, index count is the library).
static long long FLLRegularPageCount(id controller) {
    @try {
        id lists = FLLCallObject(controller, @selector(iconListViews));
        if ([lists isKindOfClass:NSArray.class]) return (long long)[lists count];
        id folder = FLLCallObject(controller, @selector(folder));
        if (folder) {
            long long c = FLLCallLongLong(folder, @selector(listCount));
            if (c > 0) return c;
            c = FLLCallLongLong(folder, @selector(iconListCount));
            if (c > 0) return c;
            id flists = FLLCallObject(folder, @selector(lists));
            if ([flists isKindOfClass:NSArray.class]) return (long long)[flists count];
        }
        long long pc = FLLCallLongLong(controller, @selector(pageCount));
        if (pc > 0) return pc - 1; // pageCount includes the library page
    } @catch (__unused id e) {}
    return -1;
}

static BOOL FLLIsLibraryPageRequest(id controller, long long index) {
    long long count = FLLRegularPageCount(controller);
    if (count <= 0) return NO;
    return index >= count;
}

// ----- bounce back when blocking starts while user sits in the library -----
- (void)bounceBackIfNeeded {
    @try {
        id controller = nil;
        Class iconCls = NSClassFromString(@"SBIconController");
        if (iconCls && [iconCls respondsToSelector:@selector(sharedInstance)]) {
            id ic = [iconCls performSelector:@selector(sharedInstance)];
            controller = FLLCallObject(ic, @selector(rootFolderController));
            if (!controller) controller = FLLCallObject(ic, @selector(folderController));
        }
        if (!controller) {
            Class mgrCls = NSClassFromString(@"SBHIconManager");
            if (mgrCls && [mgrCls respondsToSelector:@selector(sharedInstance)]) {
                id mgr = [mgrCls performSelector:@selector(sharedInstance)];
                controller = FLLCallObject(mgr, @selector(rootFolderController));
                if (!controller) controller = FLLCallObject(mgr, @selector(folderController));
            }
        }
        if (!controller) return;
        long long current = FLLCallLongLong(controller, @selector(currentPageIndex));
        if (current < 0) current = FLLCallLongLong(controller, @selector(currentIndex));
        long long count = FLLRegularPageCount(controller);
        if (current < 0 || count <= 0 || current < count) return; // not in library
        long long target = count - 1;
        FLLLog(@"BOUNCE_BACK current=%lld target=%lld", current, target);
        for (NSString *selName in @[@"setCurrentPageIndex:animated:completion:", @"setCurrentPageIndex:animated:", @"setCurrentIndex:animated:completion:", @"setCurrentIndex:animated:"]) {
            SEL sel = NSSelectorFromString(selName);
            if (![controller respondsToSelector:sel]) continue;
            @try {
                NSMethodSignature *sig = [controller methodSignatureForSelector:sel];
                NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
                inv.target = controller; inv.selector = sel;
                long long idx = target; BOOL anim = YES; id completion = nil;
                [inv setArgument:&idx atIndex:2];
                [inv setArgument:&anim atIndex:3];
                if (sig.numberOfArguments > 4) [inv setArgument:&completion atIndex:4];
                [inv invoke];
                FLLLog(@"BOUNCE_BACK_SENT via %@", selName);
                return;
            } @catch (id e) { FLLNoteException(@"bounceBackInvoke", e); }
        }
    } @catch (id e) { FLLNoteException(@"bounceBack", e); }
}

// ----- method dump (diagnostics, once) -----
- (void)dumpCandidateMethods {
    NSArray<NSString *> *classes = @[
        @"SBAppLibraryController", @"SBHAppLibraryController",
        @"SBFolderController", @"SBRootFolderController",
        @"SBHFolderController", @"SBHRootFolderController",
        @"SBRootFolderViewController", @"SBHRootFolderViewController",
        @"SBIconController", @"SBHIconManager", @"SBIconScrollView",
    ];
    for (NSString *name in classes) {
        @try {
            Class cls = NSClassFromString(name);
            if (!cls) { FLLLog(@"METHOD_DUMP %@: CLASS_NOT_FOUND", name); continue; }
            NSMutableArray<NSString *> *hits = [NSMutableArray array];
            unsigned int n = 0;
            Method *methods = class_copyMethodList(cls, &n);
            for (unsigned int i = 0; i < n; i++) {
                NSString *sel = NSStringFromSelector(method_getName(methods[i]));
                NSString *low = [sel lowercaseString];
                if ([low containsString:@"librar"] || [low containsString:@"trailingcustom"] ||
                    [low containsString:@"currentpage"] || [low containsString:@"currentindex"] ||
                    [low containsString:@"pagecount"] || [low containsString:@"scrollto"]) {
                    [hits addObject:sel];
                }
            }
            if (methods) free(methods);
            FLLLog(@"METHOD_DUMP %@: %@", name, [hits componentsJoinedByString:@", "]);
        } @catch (id e) { FLLNoteException(@"dumpMethods", e); }
    }
}

// ----- swizzles -----
- (void)installSwizzles {
    if (self.swizzlesDone) return;
    self.swizzlesDone = YES;
    if (!self.origIMPs) self.origIMPs = [NSMutableDictionary dictionary];

    NSArray<NSString *> *classes = @[
        @"SBAppLibraryController", @"SBHAppLibraryController",
        @"SBFolderController", @"SBRootFolderController",
        @"SBHFolderController", @"SBHRootFolderController",
        @"SBRootFolderViewController", @"SBHRootFolderViewController",
        @"SBIconController", @"SBHIconManager",
    ];
    NSArray<NSString *> *boolGetters = @[
        @"isAppLibraryAllowed", @"isAppLibraryEnabled", @"appLibraryEnabled",
        @"hasTrailingCustomViewController", @"isTrailingCustomViewControllerEnabled",
        @"trailingCustomViewControllerEnabled", @"isAppLibraryPresented",
    ];
    NSArray<NSString *> *pageSetters = @[
        @"setCurrentPageIndex:animated:", @"setCurrentPageIndex:animated:completion:",
        @"setCurrentIndex:animated:", @"setCurrentIndex:animated:completion:",
    ];

    for (NSString *clsName in classes) {
        @try {
            Class cls = NSClassFromString(clsName);
            if (!cls) continue;

            // A/B: zero-arg getters
            for (NSString *selName in [boolGetters arrayByAddingObject:@"trailingCustomViewController"]) {
                @try {
                    SEL sel = NSSelectorFromString(selName);
                    Method m = class_getInstanceMethod(cls, sel);
                    if (!m || method_getNumberOfArguments(m) != 2) continue;
                    char ret[8] = {0};
                    method_getReturnType(m, ret, sizeof(ret));
                    BOOL isBoolGetter = (ret[0] == 'B' || ret[0] == 'c');
                    BOOL isObjGetter = (ret[0] == '@');
                    if ([selName isEqualToString:@"trailingCustomViewController"] && !isObjGetter) continue;
                    if (![selName isEqualToString:@"trailingCustomViewController"] && !isBoolGetter) continue;
                    // isAppLibraryPresented is state, not permission: do not swizzle it.
                    if ([selName isEqualToString:@"isAppLibraryPresented"]) continue;
                    IMP orig = method_getImplementation(m);
                    NSString *key = [NSString stringWithFormat:@"%@|%@", clsName, selName];
                    if (self.origIMPs[key]) continue;
                    self.origIMPs[key] = [NSValue valueWithPointer:(void *)orig];
                    if (isObjGetter) {
                        IMP repl = imp_implementationWithBlock(^id(id _self) {
                            @try {
                                if (gBlocking) return nil;
                                return ((id (*)(id, SEL))orig)(_self, sel);
                            } @catch (__unused id e) { return nil; }
                        });
                        method_setImplementation(m, repl);
                    } else {
                        IMP repl = imp_implementationWithBlock(^BOOL(id _self) {
                            @try {
                                if (gBlocking) return NO;
                                return ((BOOL (*)(id, SEL))orig)(_self, sel);
                            } @catch (__unused id e) { return YES; }
                        });
                        method_setImplementation(m, repl);
                    }
                    FLLLog(@"SWIZZLE_INSTALLED %@ -%@", clsName, selName);
                } @catch (id e) { FLLNoteException(@"swizzleGetter", e); }
            }

            // C: page setters (integer, BOOL[, completion])
            for (NSString *selName in pageSetters) {
                @try {
                    SEL sel = NSSelectorFromString(selName);
                    Method m = class_getInstanceMethod(cls, sel);
                    if (!m) continue;
                    unsigned int argc = method_getNumberOfArguments(m);
                    if (argc != 4 && argc != 5) continue;
                    char a2[8] = {0}, a3[8] = {0};
                    method_getArgumentType(m, 2, a2, sizeof(a2));
                    method_getArgumentType(m, 3, a3, sizeof(a3));
                    BOOL intArg = (a2[0] == 'q' || a2[0] == 'Q' || a2[0] == 'i' || a2[0] == 'I' || a2[0] == 'l' || a2[0] == 'L');
                    BOOL boolArg = (a3[0] == 'B' || a3[0] == 'c');
                    if (!intArg || !boolArg) continue;
                    IMP orig = method_getImplementation(m);
                    NSString *key = [NSString stringWithFormat:@"%@|%@", clsName, selName];
                    if (self.origIMPs[key]) continue;
                    self.origIMPs[key] = [NSValue valueWithPointer:(void *)orig];
                    if (argc == 4) {
                        IMP repl = imp_implementationWithBlock(^(id _self, long long idx, BOOL anim) {
                            @try {
                                if (gBlocking && FLLIsLibraryPageRequest(_self, idx)) {
                                    FLLLog(@"BLOCKED_PAGE_SET %@ %@ -> %lld", clsName, selName, idx);
                                    return;
                                }
                                ((void (*)(id, SEL, long long, BOOL))orig)(_self, sel, idx, anim);
                            } @catch (id e) { FLLNoteException(@"pageSetter4", e); }
                        });
                        method_setImplementation(m, repl);
                    } else {
                        IMP repl = imp_implementationWithBlock(^(id _self, long long idx, BOOL anim, id completion) {
                            @try {
                                if (gBlocking && FLLIsLibraryPageRequest(_self, idx)) {
                                    FLLLog(@"BLOCKED_PAGE_SET %@ %@ -> %lld", clsName, selName, idx);
                                    return;
                                }
                                ((void (*)(id, SEL, long long, BOOL, id))orig)(_self, sel, idx, anim, completion);
                            } @catch (id e) { FLLNoteException(@"pageSetter5", e); }
                        });
                        method_setImplementation(m, repl);
                    }
                    FLLLog(@"SWIZZLE_INSTALLED %@ -%@", clsName, selName);
                } @catch (id e) { FLLNoteException(@"swizzleSetter", e); }
            }
        } @catch (id e) { FLLNoteException(@"installSwizzlesClass", e); }
    }
    FLLLog(@"SWIZZLES_DONE exceptions=%ld", (long)gExceptionCount);
}

// ----- setup -----
- (void)setup {
    if (self.setupDone) return;
    self.setupDone = YES;
    FLLLog(@"SETUP_START version=1.0.0");
    [self dumpCandidateMethods];
    [self installSwizzles];
    [self poll];
    self.pollTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES
        block:^(NSTimer *t) { [[FLLManager shared] poll]; }];
    FLLLog(@"SETUP_DONE");
}

@end

#pragma clang diagnostic pop
