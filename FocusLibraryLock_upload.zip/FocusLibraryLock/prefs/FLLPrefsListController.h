#import <Preferences/PSListController.h>

@interface FLLPrefsListController : PSListController
@end
