#import "FLLPrefsListController.h"

@implementation FLLPrefsListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

// The tweak (SpringBoard, same mobile user) owns the log file, and the
// Settings app also runs as mobile, so it can remove it directly.
- (void)clearLog:(id)sender {
    (void)sender;
    for (NSString *path in @[@"/var/mobile/Library/Logs/FocusLibraryLock.log",
                             @"/var/tmp/FocusLibraryLock.log"]) {
        [NSFileManager.defaultManager removeItemAtPath:path error:nil];
    }
    CFPreferencesSetAppValue(CFSTR("FLLClearLogToken"),
                             (__bridge CFPropertyListRef)[NSString stringWithFormat:@"%f", [[NSDate date] timeIntervalSince1970]],
                             CFSTR("com.tori.focuslibrarylock"));
    CFPreferencesAppSynchronize(CFSTR("com.tori.focuslibrarylock"));
}

@end
