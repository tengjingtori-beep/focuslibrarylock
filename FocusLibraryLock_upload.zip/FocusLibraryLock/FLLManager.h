#import <Foundation/Foundation.h>

// FocusLibraryLock manager: polls the current Focus state, decides whether
// the App Library must be blocked right now, installs the (guarded) hooks
// that block it, and writes a diagnostic log.
@interface FLLManager : NSObject
+ (instancetype)shared;
- (void)setup;
- (void)reloadPrefs;
+ (BOOL)shouldBlock;
+ (void)logLine:(NSString *)line;
@end

// Shared prefs / logging helpers used by Tweak.x too.
void FLLLoadPrefs(void);
void FLLLog(NSString *format, ...);
