// FocusLibraryLock — entry point
// iPhone 7 / iOS 15 / Dopamine (rootless) / SpringBoard only.
// All real work lives in FLLManager. This file only starts the manager
// after SpringBoard has finished launching and forwards prefs changes.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "FLLManager.h"

@interface SpringBoard : UIApplication
@end

static void fllPrefsChanged(CFNotificationCenterRef center, void *observer,
                              CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[FLLManager shared] reloadPrefs];
    });
}

%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    FLLLog(@"SPRINGBOARD_LAUNCHED");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[FLLManager shared] setup];
    });
}
%end

%ctor {
    @autoreleasepool {
        FLLLoadPrefs();
        FLLLog(@"DYLIB_LOADED version=1.0.0");
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
            fllPrefsChanged, (__bridge CFStringRef)@"com.tori.focuslibrarylock.changed", NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);
        %init;
    }
}
